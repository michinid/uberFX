<!DOCTYPE HTML>
<html <?php language_attributes() ?>>
<?php get_header() ?>
	<body>
		<div id="wrapper">
		<p>BODY</p>
			<?php if ( have_posts() ) : ?>
				<?php while ( have_posts() ) : the_post() ?>
				<div class="post">
					<h1>타이틀 : <?php the_title() ?></h1>
					<p>날짜 : <?php the_date() ?></p>
					<p>시간 : <?php the_time() ?></p>
					<p>작성자 : <?php the_author() ?></p>
					<p>카테고리 : <?php the_category(' and ') ?></p>
					<p>태그 : <?php the_tags('') ?></p>
					<p>주소 : <?php the_permalink() ?></p>
					<div class="content">글 : <?php the_content() ?></div>
				</div>
				<?php endwhile; ?>
			<?php else : ?>
				<p>글 없음</p>
			<?php endif; ?>
			<?php get_footer() ?>
		</div>
		<script src="http://code.jquery.com/jquery-latest.js"></script>
	</body>
</html>