	<head>
		<title><?php bloginfo('name'); ?></title>
		<meta charset="<?php bloginfo('charset'); ?>"/>
		<meta name="author" content="Kim Minwook - michinid@gmail.com"/>
		<meta name="keywords" content="minwook,michinid,michinid.com,michinblog,michinid blog,flash,actionscript,javascript,jquery,html,html5,css,css3"/>
		<meta name="description" content="michinblog <?php bloginfo('description'); ?>"/>
		<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>"/>
	</head>
