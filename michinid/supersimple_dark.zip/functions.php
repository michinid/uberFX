<?php
/**
 * Function
 *
 * @file           function.php
 * @package        supersimple dark 
 * @author         Kim, Minwook
 * @copyright      2012 michinid.com
 * @version        Release: 1.0
 */
?>
<?php
  add_theme_support( 'automatic-feed-links' );
	// Widget
	if ( function_exists('register_sidebar') ) {

		register_sidebar(array(
			'name' => 'Footer',
			'id' => 'one',
			'description' => 'Widgets in this area will be shown on the footer.',
			'before_widget' => '<div class="widget" role="complementary">',
			'after_widget'  => '</div>',
			'before_title' => '<h3>',
			'after_title' => '</h3>'
		));
	}

?>