<?php
/**
 * Header
 *
 * @file           header.php
 * @package        supersimple dark 
 * @author         Kim, Minwook
 * @copyright      2012 michinid.com
 * @version        Release: 1.0
 */
?>
<head>
  <title><?php bloginfo('name'); ?></title>
  <meta charset="<?php bloginfo('charset'); ?>"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
  <meta name="author" content="Kim Minwook - michinid@gmail.com"/>
  <meta name="keywords" content="minwook,michinid,michinid.com,flash,actionscript,javascript,jquery,html,html5,css,css3"/>
  <meta name="description" content="michinblog <?php bloginfo('description'); ?>"/>
  <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>"/>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
  <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.preload.js"></script>
  <script src="<?php echo get_template_directory_uri(); ?>/js/oscheck.js"></script>
  <?php wp_head(); ?>
</head>
