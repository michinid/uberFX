<?php
/**
 * Index
 *
 * @file           index.php
 * @package        supersimple dark 
 * @author         Kim, Minwook
 * @copyright      2012 michinid.com
 * @version        Release: 1.0
 */
?>
<!DOCTYPE HTML>
<html <?php language_attributes() ?>>
<?php get_header() ?>
  <body <?php body_class(); ?>>
    <div id="wrapper">
      <header id="header">
        <h1><a href="<?php bloginfo('url'); ?>/"><?php bloginfo('name'); ?></a></h1>
        <p><?php bloginfo('description'); ?></p>
      </header>
      <div id="view">
        <?php if ( have_posts() ) : ?>
        <?php while ( have_posts() ) : the_post() ?>
        <section class="post">
          <div class="meta">
            <h1><a href="<?php the_permalink() ?>" target="_self"><?php the_title() ?></a></h1>
            <p>CATEGORY : <?php the_category(', ') ?><?php the_tags(' | TAG: ') ?></p>
            <p><?php the_date() ?> | <?php the_time() ?> | Post by <?php the_author() ?><?php edit_post_link(__(' - [ EDIT ]')); ?></p>
           </div>
          <div class="write">
<!-- Post START -->
<?php the_content() ?>
<!-- Post END -->
          </div>
        </section>
        <?php endwhile; ?>
        <?php else : ?>
        <p>글 없음</p>
        <?php endif; ?>
      </div>
      <nav class="arrow">
        <?php wp_pagenavi() ?>
      </nav>
      <div id="widget" class="three">
        <?php dynamic_sidebar( 'Footer' ); ?>
      </div>
      <?php get_footer() ?>
    </div>
    <script>
    $(function(){
      function addImageLink(){
        $.each($("#view img"), function(index){
          $(this).wrap('<a href="' + $(this).attr("src") + '" target="_blank"/>');
        });
      }
    });
    function mobilecheck(more){
      if( BrowserDetect.isPad() || BrowserDetect.isMobile() ) {
        $("#wrapper #view .post .write object").hide();
        $("#wrapper #view .post .write").prepend("<p class='alert'>This device does not recommend flash.</p><p class='alert'>이 장치는 플래시를 권장하지 않습니다.</p>" + more);
      }
    }
    </script>
  </body>
</html>