<?php
/**
 * Footer
 *
 * @file           footer.php
 * @package        supersimple dark 
 * @author         Kim, Minwook
 * @copyright      2012 michinid.com
 * @version        Release: 1.0
 */
?>
<div id="footer">
	<p>&copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?> All right reserved.</p>
  <p>Powered by <a href="http://wordpress.org/" target="_blank">WordPress</a> | <?php wp_loginout(); ?></p>
  <p>Theme by <a href="http://michinid.com/blog" target="_blank">michinid</a></p>
</div>
<?php wp_footer(); ?>
